// Wait until the DOM is ready
document.addEventListener("DOMContentLoaded", function () {
    
    // 1️⃣ Confirm before deleting a product (admin side)
    const deleteLinks = document.querySelectorAll(".delete-link");
    deleteLinks.forEach(link => {
        link.addEventListener("click", function (e) {
            if (!confirm("Are you sure you want to delete this item?")) {
                e.preventDefault();
            }
        });
    });

    // 3️⃣ Animate Add to Cart button click
    const cartButtons = document.querySelectorAll(".btn-custom");
    cartButtons.forEach(btn => {
        btn.addEventListener("click", function () {
            btn.innerText = "✓ Added!";
            btn.style.backgroundColor = "#198754"; // Bootstrap green
            setTimeout(() => {
                btn.innerText = "Add to Cart";
                btn.style.backgroundColor = "";
            }, 1500);
        });
    });

    // 4️⃣ Highlight active nav link automatically
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll(".navbar .nav-link");
    navLinks.forEach(link => {
        if (link.getAttribute("href") && currentPath.includes(link.getAttribute("href"))) {
            link.classList.add("active");
        }
    });

});
