package com.ecommerce.dao;

import com.ecommerce.model.User;
import com.ecommerce.utils.DBUtil;


import java.sql.*;

public class UserDAO {
    private Connection getConnection() throws SQLException {
        // Update DB name, username, password if needed
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "mysql@123");
    }

    // ✅ Validate login and return User object if success
    public User validateUser(String email, String password) {
    String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    try (Connection conn = DBUtil.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ps.setString(2, password);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                return user;
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
    return null; // login failed
}

    // ✅ For registration (if you don’t already have it)
    public boolean registerUser(User user) {
    String sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
    try (Connection conn = DBUtil.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, user.getUsername());
        ps.setString(2, user.getEmail());
        ps.setString(3, user.getPassword());
        ps.setString(4, "user"); // ✅ always new user is "user"

        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

}
