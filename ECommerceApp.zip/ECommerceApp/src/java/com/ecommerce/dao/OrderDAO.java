package com.ecommerce.dao;

import com.ecommerce.model.CartItem;
import com.ecommerce.utils.DBUtil;

import java.sql.*;
import java.util.*;

public class OrderDAO {

    // ✅ Create a new order and its items
    public int createOrder(String userEmail, double total, List<CartItem> cart, String address, String paymentMethod) {
        String orderSql = "INSERT INTO orders (user_email, total_amount, order_date, address, payment_method) VALUES (?, ?, NOW(), ?, ?)";
        String itemSql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement orderPs = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {

            // Insert order
            orderPs.setString(1, userEmail);
            orderPs.setDouble(2, total);
            orderPs.setString(3, address);
            orderPs.setString(4, paymentMethod);

            int rows = orderPs.executeUpdate();
            System.out.println("DEBUG: Insert order rows = " + rows + " for user = " + userEmail);

            ResultSet rs = orderPs.getGeneratedKeys();
            if (rs.next()) {
                int orderId = rs.getInt(1);

                // Insert items
                try (PreparedStatement itemPs = conn.prepareStatement(itemSql)) {
                    for (CartItem item : cart) {
                        itemPs.setInt(1, orderId);
                        itemPs.setInt(2, item.getProduct().getId());
                        itemPs.setInt(3, item.getQuantity());
                        itemPs.setDouble(4, item.getProduct().getPrice());
                        itemPs.addBatch();
                    }
                    itemPs.executeBatch();
                }

                System.out.println("DEBUG: Order created with ID = " + orderId);
                return orderId;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    // ✅ Get all orders for a specific user
    public List<Map<String, Object>> getOrdersByUser(String userEmail) {
        List<Map<String, Object>> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE user_email = ? ORDER BY order_date DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, userEmail);
            System.out.println("DEBUG SQL: " + ps); // ✅ Print executed query

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, Object> order = new HashMap<>();
                order.put("id", rs.getInt("id"));
                order.put("user_email", rs.getString("user_email"));
                order.put("total_amount", rs.getDouble("total_amount"));
                order.put("order_date", rs.getTimestamp("order_date"));
                order.put("address", rs.getString("address"));
                order.put("payment_method", rs.getString("payment_method"));
                orders.add(order);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("DEBUG: Found orders count = " + orders.size() + " for user = " + userEmail);
        return orders;
    }

    // ✅ Get all orders (for admin)
    public List<Map<String, Object>> getAllOrders() {
        List<Map<String, Object>> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders ORDER BY order_date DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, Object> order = new HashMap<>();
                order.put("id", rs.getInt("id"));
                order.put("user_email", rs.getString("user_email"));
                order.put("total_amount", rs.getDouble("total_amount"));
                order.put("order_date", rs.getTimestamp("order_date"));
                order.put("address", rs.getString("address"));
                order.put("payment_method", rs.getString("payment_method"));
                orders.add(order);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    // ✅ Get items for a specific order
    public List<Map<String, Object>> getOrderItems(int orderId) {
        List<Map<String, Object>> items = new ArrayList<>();
        String sql = "SELECT oi.*, p.name AS product_name " +
                     "FROM order_items oi " +
                     "JOIN products p ON oi.product_id = p.id " +
                     "WHERE oi.order_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, Object> item = new HashMap<>();
                item.put("product_id", rs.getInt("product_id"));
                item.put("product_name", rs.getString("product_name"));
                item.put("quantity", rs.getInt("quantity"));
                item.put("price", rs.getDouble("price"));
                item.put("total", rs.getDouble("price") * rs.getInt("quantity"));
                items.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return items;
    }
}
