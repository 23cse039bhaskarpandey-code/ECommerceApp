package com.ecommerce.servlets;

import com.ecommerce.dao.ProductDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/delete-product")
public class DeleteProductServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));

        ProductDAO dao = new ProductDAO();
        boolean success = dao.deleteProduct(id);

        if (success) {
            response.sendRedirect("admin/products");
        } else {
            response.getWriter().println("Failed to delete product with ID: " + id);
        }
    }
}
