package com.ecommerce.servlets;

import com.ecommerce.dao.OrderDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/admin/order-details")
public class AdminOrderDetailsServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int orderId = Integer.parseInt(request.getParameter("id"));
        request.setAttribute("items", orderDAO.getOrderItems(orderId));
        request.setAttribute("orderId", orderId);
        request.getRequestDispatcher("admin_order_details.jsp").forward(request, response);
    }
}
