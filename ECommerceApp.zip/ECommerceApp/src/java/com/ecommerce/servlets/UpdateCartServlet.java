package com.ecommerce.servlets;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.Product;
import com.ecommerce.dao.ProductDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/update-cart")
public class UpdateCartServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

        if (cart != null) {
            String[] productIds = request.getParameterValues("productIds");
            String[] quantities = request.getParameterValues("quantities");

            if (productIds != null && quantities != null) {
                for (int i = 0; i < productIds.length; i++) {
                    int productId = Integer.parseInt(productIds[i]);
                    int qty = Integer.parseInt(quantities[i]);

                    for (CartItem item : cart) {
                        if (item.getProduct().getId() == productId) {
                            item.setQuantity(qty);
                            break;
                        }
                    }
                }
            }

            session.setAttribute("cart", cart);
        }

        response.sendRedirect("cart.jsp"); // ✅ reload cart
    }
}
