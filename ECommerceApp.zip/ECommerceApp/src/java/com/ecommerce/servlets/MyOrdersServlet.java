package com.ecommerce.servlets;

import com.ecommerce.dao.OrderDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/my-orders")   // ✅ clean URL for navbar
public class MyOrdersServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String userEmail = (String) session.getAttribute("email");

        // Debugging: print the email being used
        System.out.println("DEBUG MyOrders: looking for orders with email = " + userEmail);

        List<Map<String, Object>> orders = orderDAO.getOrdersByUser(userEmail);

        // Debugging: show count
        System.out.println("DEBUG MyOrders: found " + orders.size() + " orders");

        request.setAttribute("orders", orders);
        request.getRequestDispatcher("my_orders.jsp").forward(request, response);
    }
}
