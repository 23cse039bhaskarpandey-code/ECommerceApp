package com.ecommerce.servlets;

import com.ecommerce.dao.UserDAO;
import com.ecommerce.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = userDAO.validateUser(email, password);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("username", user.getUsername());  // ✅ store username
            session.setAttribute("email", user.getEmail());        // ✅ store email
            session.setAttribute("role", user.getRole());          // ✅ store role

            // Debugging
            System.out.println("DEBUG Login: username=" + user.getUsername() + ", email=" + user.getEmail());

            response.sendRedirect("welcome.jsp");
        } else {
            request.setAttribute("error", "❌ Invalid email or password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
