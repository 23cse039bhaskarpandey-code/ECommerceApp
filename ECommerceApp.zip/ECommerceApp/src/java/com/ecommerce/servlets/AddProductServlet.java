package com.ecommerce.servlets;

import com.ecommerce.dao.ProductDAO;
import com.ecommerce.model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/add-product")
public class AddProductServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");

        double price = Double.parseDouble(priceStr);

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);

        ProductDAO dao = new ProductDAO();
        boolean success = dao.addProduct(product);

        if (success) {
            response.sendRedirect("admin/products");
        } else {
            response.sendRedirect("add_product.jsp?error=1");
        }
    }
}
