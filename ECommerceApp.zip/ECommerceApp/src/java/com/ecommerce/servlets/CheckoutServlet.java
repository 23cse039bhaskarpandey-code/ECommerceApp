package com.ecommerce.servlets;

import com.ecommerce.dao.OrderDAO;
import com.ecommerce.model.CartItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String userEmail = (String) session.getAttribute("email");
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        String address = request.getParameter("address");
        String paymentMethod = request.getParameter("paymentMethod");

        // calculate total
        double grandTotal = 0;
        for (CartItem item : cart) {
            grandTotal += item.getProduct().getPrice() * item.getQuantity();
        }

        // create order
        int orderId = orderDAO.createOrder(userEmail, grandTotal, cart, address, paymentMethod);

        if (orderId > 0) {
            // ✅ pass orderId to JSP
            request.setAttribute("orderId", orderId);

            // clear cart after successful order
            session.removeAttribute("cart");

            request.getRequestDispatcher("order_success.jsp").forward(request, response);
        } else {
            response.sendRedirect("checkout.jsp?error=1");
        }
    }
}
