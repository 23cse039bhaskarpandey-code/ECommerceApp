package com.ecommerce.utils;

import java.sql.Connection;
public class TestDBConnection {
    public static void main(String[] args) {
        try {
            Connection con = DBUtil.getConnection();
            if (con != null) {
                System.out.println("✅ Database Connected Successfully!");
                con.close();
            }
        } catch (Exception e) {
            System.out.println("❌ Database Connection Failed!");
            e.printStackTrace();
        }
    }
}
