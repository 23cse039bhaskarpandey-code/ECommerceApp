package com.ecommerce.utils;
import java.sql.*;

public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/ecommerce";
    private static final String USER = "root";  
    private static final String PASS = "mysql@123";  

    public static Connection getConnection() throws SQLException {
        Connection conn = null;
        try {
            // Explicitly load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASS);
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL Driver not found. Please check the JAR in Tomcat lib.");
            e.printStackTrace();
        }
        return conn;
    }
}
